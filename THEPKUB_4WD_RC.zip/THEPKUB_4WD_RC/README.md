# THEPKUB 4WD ESP32 RC CAR

แอปควบคุมรถ (แนวนอน) + โค้ดบอร์ด ESP32 พร้อมสร้าง APK อัตโนมัติด้วย GitHub Actions

## สร้าง APK (ไม่ต้องติดตั้งอะไรในเครื่อง)
1. สร้าง repo ใหม่บน GitHub แล้วอัปโหลดทุกไฟล์ในโฟลเดอร์นี้ (รวมโฟลเดอร์ `.github`)
   - อัปโหลดผ่านเว็บแบบลากวางมักไม่รับโฟลเดอร์ที่ขึ้นต้นด้วยจุด แนะนำใช้ git:
     `git init && git add -A && git commit -m init && git branch -M main && git remote add origin <URL> && git push -u origin main`
2. เปิดแท็บ **Actions** > **Build APK** (รันอัตโนมัติเมื่อ push หรือกด Run workflow)
3. รอประมาณ 5-8 นาที แล้วโหลดไฟล์ `THEPKUB-4WD-apk` จากหัวข้อ Artifacts (แตกซิปได้ `THEPKUB-4WD.apk`)
4. ติดตั้งบนมือถือ (อนุญาตติดตั้งแอปจากแหล่งที่ไม่รู้จัก)

ถ้า push แท็กเช่น `v1.0` ไฟล์ APK จะแนบไว้ที่หน้า Releases ให้ด้วย

## บอร์ด ESP32
เปิด `firmware/THEPKUB_4WD_RC/THEPKUB_4WD_RC.ino` ใน Arduino IDE (บอร์ด ESP32 Dev Module) แล้วอัปโหลด

| L298N | ESP32 | | L298N | ESP32 |
|---|---|---|---|---|
| ENA | GPIO 25 | | IN3 | GPIO 14 |
| IN1 | GPIO 26 | | IN4 | GPIO 32 |
| IN2 | GPIO 27 | | ENB | GPIO 33 |

ต่อมอเตอร์ **ซ้าย 2 ตัว (อนุกรม) ที่ OUT1/OUT2** และ **ขวา 2 ตัวที่ OUT3/OUT4** เพื่อให้เลี้ยวได้

## การใช้งานแอป
- **Wi‑Fi:** ต่อ `THEPKUB_4WD_WIFI` (รหัส 12345678) ก่อน แล้วกดการ์ด Wi‑Fi (ถ้าเชื่อมไม่ติด ลองปิดเน็ตมือถือ)
- **Bluetooth:** จับคู่ `THEPKUB_4WD_RC` ในตั้งค่ามือถือก่อน แล้วกดการ์ด Bluetooth
- **ขับ:** ซ้ายลากเพื่อเลี้ยว · ขวาเลื่อนคันเร่ง (หรือลากที่เกจกลาง) · เกียร์ D/N/R · STOP หยุดทันที

## โครงสร้าง
- `www/` หน้าเว็บแอป · `native/CarLinkPlugin.java` ปลั๊กอิน Bluetooth Classic (SPP) + บังคับใช้ Wi‑Fi
- `scripts/patch_android.py` ล็อกแนวนอน เพิ่ม permission ลงทะเบียนปลั๊กอิน ตอน build
