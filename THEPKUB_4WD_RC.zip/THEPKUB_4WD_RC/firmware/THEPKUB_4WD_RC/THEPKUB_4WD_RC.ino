/*
  THEPKUB 4WD ESP32 RC CAR
  Board : ESP32 DevKit V1 (Arduino core 2.x or 3.x)
  Driver: 1x L298N

  Channel A (ENA/IN1/IN2) = OUT1/OUT2  -> LEFT  pair (front-left + rear-left, in series)
  Channel B (ENB/IN3/IN4) = OUT3/OUT4  -> RIGHT pair (front-right + rear-right, in series)
  (Series pairs on the same axle can't steer differentially, so wire by SIDE.
   If you keep front/rear pairs, the car drives straight only.)

  Commands (Bluetooth SPP text, or HTTP GET /cmd?c=...):
    F B L R S      forward, backward, left, right, stop
    1 2 3          speed ECO / NORMAL / TURBO
    M<l>,<r>       mixed drive, each -100..100 (used by the app)
  Any valid command refreshes the fail-safe timer (1.5 s).
*/
#include <WiFi.h>
#include <WebServer.h>
#include <BluetoothSerial.h>

#if !defined(CONFIG_BT_ENABLED) || !defined(CONFIG_BLUEDROID_ENABLED)
#error "Bluetooth Classic is not enabled for this board"
#endif

// ---- Pin map ----
#define ENA 25   // PWM channel A
#define IN1 26
#define IN2 27
#define IN3 14
#define IN4 32
#define ENB 33   // PWM channel B

// ---- Settings ----
const char* BT_NAME  = "THEPKUB_4WD_RC";
const char* AP_SSID  = "THEPKUB_4WD_WIFI";
const char* AP_PASS  = "12345678";
const unsigned long FAILSAFE_MS = 1500;
const int PWM_FREQ = 1000, PWM_BITS = 8;
const int SPEED_PWM[3] = {110, 180, 255};   // ECO, NORMAL, TURBO
const int PWM_MIN = 60;                     // below this motors only hum

BluetoothSerial SerialBT;
WebServer server(80);

int speedLevel = 1;                 // 0..2
unsigned long lastCmd = 0;
bool moving = false;
String btBuf;

void pwmSetup(int pin) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(pin, PWM_FREQ, PWM_BITS);
#else
  static int ch = 0;
  ledcSetup(ch, PWM_FREQ, PWM_BITS);
  ledcAttachPin(pin, ch++);
#endif
}

void pwmWrite(int pin, int duty) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(pin, duty);
#else
  ledcWrite(pin == ENA ? 0 : 1, duty);
#endif
}

// pct: -100..100 scaled by current speed level
void drive(int en, int a, int b, int pct) {
  pct = constrain(pct, -100, 100);
  int duty = abs(pct) * SPEED_PWM[speedLevel] / 100;
  if (duty > 0 && duty < PWM_MIN) duty = PWM_MIN;
  digitalWrite(a, pct > 0);
  digitalWrite(b, pct < 0);
  pwmWrite(en, pct == 0 ? 0 : duty);
}

void setDrive(int left, int right) {
  drive(ENA, IN1, IN2, left);
  drive(ENB, IN3, IN4, right);
  moving = (left != 0 || right != 0);
}

void stopAll() { setDrive(0, 0); }

bool handleCommand(String c) {
  c.trim();
  if (c.length() == 0) return false;
  char k = toupper(c[0]);
  switch (k) {
    case 'F': setDrive(100, 100);   break;
    case 'B': setDrive(-100, -100); break;
    case 'L': setDrive(-100, 100);  break;
    case 'R': setDrive(100, -100);  break;
    case 'S': stopAll();            break;
    case '1': case '2': case '3': speedLevel = k - '1'; break;
    case 'M': {
      int comma = c.indexOf(',');
      if (comma < 0) return false;
      setDrive(c.substring(1, comma).toInt(), c.substring(comma + 1).toInt());
      break;
    }
    case 'P': break;                // ping / keep-alive
    default: return false;
  }
  lastCmd = millis();
  return true;
}

void sendCors() { server.sendHeader("Access-Control-Allow-Origin", "*"); }

void setup() {
  Serial.begin(115200);
  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pwmSetup(ENA); pwmSetup(ENB);
  stopAll();

  SerialBT.begin(BT_NAME);

  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(IPAddress(192,168,4,1), IPAddress(192,168,4,1), IPAddress(255,255,255,0));
  WiFi.softAP(AP_SSID, AP_PASS);

  server.on("/cmd", []() {
    sendCors();
    bool ok = server.hasArg("c") && handleCommand(server.arg("c"));
    server.send(ok ? 200 : 400, "text/plain", ok ? "OK" : "ERR");
  });
  server.on("/ping", []() {
    sendCors();
    lastCmd = millis();
    server.send(200, "text/plain", "THEPKUB");
  });
  server.begin();
  Serial.println("THEPKUB 4WD ready: BT=" + String(BT_NAME) + "  WiFi=192.168.4.1");
}

void loop() {
  server.handleClient();

  while (SerialBT.available()) {
    char ch = SerialBT.read();
    if (ch == '\n' || ch == '\r') { handleCommand(btBuf); btBuf = ""; }
    else if (btBuf.length() < 24) btBuf += ch;
    // single-letter commands without newline (terminal apps)
    if (btBuf.length() == 1 && strchr("FBLRSfblrs123P", btBuf[0])) {
      handleCommand(btBuf); btBuf = "";
    }
  }

  // Fail-safe: no valid command for 1.5 s -> cut motors
  if (moving && millis() - lastCmd > FAILSAFE_MS) stopAll();
}
